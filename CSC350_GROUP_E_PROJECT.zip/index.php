<!DOCTYPE html>
<?php
include 'connection.php';
$SQL="select * from class_schedule";
$SQL=mysqli_query($conn, $SQL);
if(mysqli_num_rows($SQL)>0)
echo
'<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> CIS Department</title>
    <link rel="stylesheet" href="index.css">
  </head>
  <body>
    <div class="">
      <div class="image">
          <a class="link" href="https://www.bmcc.cuny.edu/" target="_blank"><img src="bmcc4.png" alt="BMCC" height="150" height="150"></a>
      </div>

      <div class="social">
        <a href="mailto:llcttt@gmail.com "><img id="gmail" src="gmail.png" alt="gmail" height="30" height="30"></a>
        <a href="mailto:william.zhicay@stu.bmcc.cuny.edu"><img src="outlook.png" alt="outlook" height="30" height="30"></a>
      </div>
    </div>
  <div class="row">
    <div class="col">
      <a class="link" href="aupload.php" target="_blank"><img  class="zoom" id="db"src="db.png" alt="" width="200" height="200"></a><br>
      <button class="button" type="button" name="button"><a class="link" href="aupload.php" >Import CSV Files</a></button>
    </div>
    <div class="col">
      <a class="link" href="T.php" target="_blank"><img  class="zoom" id="sche"src="schedule.png" width="225" height="200" alt=""></a><br>
      <button id="leftButton2" class="button" type="button" name="button"><a class="link" href="T.php" >Go To Table</a></button>
    </div>
    <div class="col">
      <a class="link" href="list.php" target="_blank"><img class="zoom" id="sche"src="list.png" width="225" height="200" alt=""></a><br> <!–– needs to be linked to a file-->
      <button id="leftButton3" class="button" type="button" name="button"><a class="link" href="list.php">View List </a></button>
    </div>
    <div class="col">

      <a class="link" ><img class="zoom" id="sche"src="delete.png" width="225" height="200" alt=""></a><br> <!–– needs to be linked to a file-->
       <form action="index.php" method="post">
      <button type="submit" id="leftButton4" class="button" name="button" > <a class="link">Clear schedule</a> </button>
      </form>
    </div>
  </div>
  </body>
</html>';
else
echo
'<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> CIS Department</title>
    <link rel="stylesheet" href="index2.css">
  </head>
  <body>
    <div class="">
      <div class="image">
          <a class="link"  ><img id="help"src="help.png" alt="need help?" height="50" height="50" title="Unlock table and schedule after uploading the files"/></a>
      </div>

      <div class="social">
        <a href="mailto:llcttt@gmail.com "><img id="gmail" src="gmail.png" alt="gmail" height="30" height="30"></a>
        <a href="mailto:william.zhicay@stu.bmcc.cuny.edu"><img src="outlook.png" alt="outlook" height="30" height="30"></a>
      </div>
    </div>
  <div class="row">
    <div class="col">

    <a class="link1" href="aupload.php" target="_blank"><img  class="zoom" id="db"src="db.png" alt="" width="200" height="200"></a><br>
    <button class="button" type="button" name="button"><a class="link" href="aupload.php" >Import CSV Files</a></button>
    </div>
    <div class="col">
    <a class="link2" ><img  class="zoom" id="sche"src="table2.png" width="225" height="200" alt=""></a><br>
    <button id="leftButton2" class="button" type="button" name="button"><a class="link"  >Go To Table</a></button>
    </div>
    <div class="col">
      <a class="link3" ><img class="zoom" id="sche"src="list2.png" width="225" height="200" alt=""></a><br> <!–– needs to be linked to a file-->
      <button id="leftButton3" class="button" type="button" name="button"><a class="link" >View List </a></button>
    </div>
    <div class="col">
      <a class="link4"  target="_blank"><img class="zoom" id="sche"src="delete.png" width="225" height="200" alt=""></a><br> <!–– needs to be linked to a file-->
      <button id="leftButton4" class="button" type="button" name="button"><a class="link">Clear Schedule </a></button>
    </div>
  </div>
  </body>
</html>';
if(isset($_POST["button"])&&mysqli_num_rows($SQL)>0)
{
  echo "<script>alert('Deleted')</script>";
  $myQ="Delete from class_schedule";
  $esult = mysqli_query($conn, $myQ);
  $esult = mysqli_query($conn, $myQ);
  $myQ="ALTER TABLE class_schedule AUTO_INCREMENT = 1";
}
?>
