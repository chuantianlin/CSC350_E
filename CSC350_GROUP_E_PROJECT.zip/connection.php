<?php
$conn = mysqli_connect("localhost", "root", "", "class_arrangement");
?>
